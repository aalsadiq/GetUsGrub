<template>
  <div>
    <app-admin-header/>
    <v-flex xs3 sm10 offset-sm2>
    <app-create-user/>
    </v-flex>
    <app-footer/>
  </div>
</template>

<script>
import AppCreateUser from '@/components/CreateUser'
import AdminHeader from '@/components/AdminUserManagement/AdminHeader'
import AppFooter from '@/components/AppFooter'
export default {
  name: 'CreateUser',
  components: {
    'app-create-user': AppCreateUser,
    'app-admin-header': AdminHeader,
    'app-footer': AppFooter
  }
}
</script>
