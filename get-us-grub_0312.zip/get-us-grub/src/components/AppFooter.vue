<template>
  <v-footer height="auto" class="grey darken-3" fixed>
    <v-layout row wrap justify-center>
      <v-flex xs12 py-3 text-xs-center white--text>
          &copy; {{ new Date().getFullYear() }} — <strong>GetUsGrub</strong>
      </v-flex>
    </v-layout>
  </v-footer>
</template>
