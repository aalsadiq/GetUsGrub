<template>
    <div id= "image-upload">
        <h1> Upload image </h1>
    </div>
</template>
